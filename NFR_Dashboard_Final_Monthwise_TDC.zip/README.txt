Final Month-wise TDC Chart Version

Updates:
- Removed Top Stations/L-Xings by Works chart.
- Added Month-wise Works as per TDC chart.
- Clicking a month bar (e.g. July) shows all works due in that month.
- Existing PH filtering, KPI filtering, and live Google Sheet connection retained.

Upload full extracted folder to Netlify.
